<?php
$catalog = [];
//Books
$catalog[101] = [
	"title" => "Go Ask Alice",
	"img" => "img/media/GoAskAlice.png",
 "genre" => "Fiction",
 "format" => "Paperback",
 "year" => 1971,
 "category" => "Books",
 "authors" => [
	 "Anonymous"
    ],
		"publisher" => "Prentice",
	  "isbn" => '9781501142970'
];
$catalog[102] = [
	"title" => "The Alchemist",
	"img" => "img/media/THeAlchemist.png",
 "genre" => "Fantasy Fiction",
 "format" => "Hardcover",
 "year" => 1988,
 "category" => "Books",
 "authors" => [
	 "Paulo Coelho"
    ],
		"publisher" => "HarperTorch",
	  "isbn" => '9780743412285'
];
$catalog[103] = [
	"title" => "The Outsiders",
	"img" => "img/media/TheOutsider.png",
 "genre" => "Fiction",
 "format" => "Paperback",
 "year" => 1967,
 "category" => "Books",
 "authors" => [
	 "S.E Hinton"
    ],
		"publisher" => "Viking Press",
	  "isbn" => '	9781982103521'
];
$catalog[104] = [
	"title" => "The four agreement",
	"img" => "img/media/4Elements.png",
 "genre" => "Self-Help",
 "format" => "Hardcover",
 "year" => 1997,
 "category" => "Books",
 "authors" => [
	 "Don Miguel-Ruiz"
    ],
		"publisher" => "amber-allen",
	  "isbn" => '9781501192241'
];
//Movies
$catalog[201] = [
	"title" => "The Godfather Collection",
  "img" => "img/media/theGodfather.png",
  "genre" => "Drama",
  "format" => "DVD",
  "year" => 2008,
  "category" => "Movies",
  "director" => "Francis Ford Coppola",
  "writers" => [
      "Francis Ford Coppolan",
   "Mario Puzo"
    ],
		"stars" => [
	      "Al Pacino",
	      "Robert Duvall",
	      "Diane Keaton"
    ]
];
$catalog[202] = [
	"title" => "Kids",
  "img" => "img/media/Kids.png",
  "genre" => "Indie/Drama",
  "format" => "DVD",
  "year" => 1995,
  "category" => "Movies",
  "director" => "Larry Clark",
  "writers" => [
		"Larry Clark"
    ],
		"stars" => [
			"Sylvester Stallone"
    ]
];
$catalog[203] = [
	"title" => "BLOW",
  "img" => "img/media/BLow.png",
  "genre" => "Drama",
  "format" => "DVD",
  "year" => 2001,
  "category" => "Movies",
  "director" => "Ted Demme",
  "writers" => [
      "Nick Cassavetas"
    ],
		"stars" => [
	      "Johnny Depp",
	      "Bonnie Bedelia "
    ]
];
$catalog[204] = [
	"title" => "Superbad",
	"img" => "img/media/Superbad.png",
	"genre" => "Comedy,",
	"format" => "DVD",
	"year" => 2009,
	"category" => "Movies",
	"director" => "James Cameron",
	"writers" => [
			"Sylvester Stallone",
			"Dave Callaham"
    ],
		"stars" => [
	      "Sylvester Stallone",
	      "Jason Statham",
	      "Mickey Rourke"
    ]
];
//Music
$catalog[301] = [
	"title" => "Try Again",
  "img" => "img/media/Aaliyah.png",
  "genre" => "R&B",
  "format" => "CD",
  "year" => 2000,
  "category" => "Music",
  "artist" => "Aaliyah"
];
$catalog[302] = [
	"title" => "Over The Rainbow",
  "img" => "img/media/OverTheRainbow.png",
  "genre" => "Hawaiian pop",
  "format" => "CD, Vinyl",
  "year" => 1990,
  "category" => "Music",
  "artist" => "Isreal Kamakawiwo'ole"
];
$catalog[303] = [
	"title" => "One More Time",
  "img" => "img/media/DaftPunk.png",
  "genre" => "Disco",
  "format" => "CD",
  "year" => 2015,
  "category" => "Music",
  "artist" => "Daft Punk"
];
$catalog[304] = [
	"title" => "Project Baby 2",
  "img" => "img/media/KodakBlack.png",
  "genre" => "Hip hop",
  "format" => "CD",
  "year" => 2017,
  "category" => "Music",
  "artist" => "Kodak Black"
];
